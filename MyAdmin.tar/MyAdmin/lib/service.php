
<?php


//*************************************************************************************

//                      KTBS FUNCTIONS. V.1 Created By Tarek DJOUAD. 16-10-2015
//                      Email: tarek.djouad@gmail.com

//*************************************************************************************


require_once "../config/config.php" ;


//*************************************************************************************

//                      BASIC FUNCTIONS

//*************************************************************************************


//*************************************************************************************
// this function is used to test Ktbs Get functions results
function Prview_List(&$result){
	 if ($result!=='')
	 for($i=0;$i<count($result); $i++) 
		 echo $result[$i].'<br>';

}


// this function is used to test Ktbs Get functions results
function Prview_List_with_Link(&$result,$link){
	 if ($result!=='')
	 for($i=0;$i<count($result); $i++) 
		 echo"<a href=".$link.">".$result[$i]."</a></p><br>";

}
//*************************************************************************************

//                        CURL GET AND POST FUNCTIONS: Application-JSON mode


//*************************************************************************************


//*************************************************************************************

function KTBS_Curl_Connect_Get($url)    
{
// init curl params
	    $curl = curl_init($url);    
		curl_setopt($curl, CURLOPT_HTTPGET, true);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_USERPWD, "admin".":"."admin");

// connect to ktbs and obtain ktbs database list using hasBase field		
		$result = curl_exec($curl);
		curl_close($curl);
		
        $cont = json_decode($result,true);
        return $cont; 
}


//*************************************************************************************

	function KTBS_Curl_Connect_Post($url, $content)   
{	 $header = array("Content-Type: application/json", "Expect:");
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_USERPWD, "admin".":"."admin");		
		curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
		$reponse = curl_exec($curl);
	//	$infos = curl_getinfo($curl);
        curl_close($curl);
	 
}

//*************************************************************************************
	function KTBS_Curl_Connect_Post_Turtle($url, $content)   
{		
		$header = array("Content-type:text/turtle", "Expect:");
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_USERPWD, "admin".":"."admin");		
		curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
		$reponse = curl_exec($curl);
		
        curl_close($curl);		
	 
}

//*************************************************************************************


function Ktbs_Curl_Delete($url,$content){
			
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "DELETE");
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_USERPWD, "admin".":"."admin");		
		curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
       
    
		$reponse = curl_exec($curl);
		$infos = curl_getinfo($curl);
        curl_close($curl);
		$http_code = $infos["http_code"];
		if($http_code == "201") return true; 
			else return $reponse;
}
//*************************************************************************************

//                        KTBS GET FUNCTIONS


//*************************************************************************************

function KTBS_Get_info($url)    
{
	    $cont = KTBS_Curl_Connect_Get($url);
			$id[] = $cont["@id"];	
	        $id[] = $cont["@context"];	
	        $id[] = $cont["@type"];	
	        $id[]= $cont["version"];	
	        
        return $id;
}

//*************************************************************************************
function KTBS_Get_DataBase_info($url)    
{
	  $cont = KTBS_Curl_Connect_Get($url);
			$id[] = $cont["@id"];	
	        $id[] = $cont["@type"];	
	        $id[] = $cont["label"];	
	        $id[]= $cont["inRoot"];		        
        return $id;
}



//*************************************************************************************
function KTBS_Get_Trace_Info($url)
{
	
	  $cont = KTBS_Curl_Connect_Get($url);
			$id[] = $cont["@id"];	
	        $id[] = $cont["@type"];	
	        $id[] = $cont["hasModel"];
	        $id[] = $cont["origin"];
	        if (isset ($cont["defaultSubject"]))
			   $id[] = $cont["defaultSubject"];
	        $id[] = $cont["inBase"];
			$id[] = $cont["@context"];
			
        return $id;
}
//*************************************************************************************
function KTBS_Get_DataBase_List($url)    
{
	    $cont = KTBS_Curl_Connect_Get($url);   
		if (isset($cont)) {
		if(array_key_exists('hasBase', $cont)) {
		
		     $bases = $cont['hasBase'];
		}else {
		     $bases='';
		}
        return $bases;
	 }
}

//************************************************************************************
function KTBS_Get_Traces_List($url)
{
	$listOfTrace='';
    $cont = KTBS_Curl_Connect_Get($url);
	
	if(array_key_exists('contains', $cont)) {
	
	   $contains = $cont['contains'];
	
   	   foreach (array_keys($contains) as $key) {
		    	$val = $contains[$key]["@id"];
			
			    $val = str_replace('./', '', $val);
			    if ($val[strlen($val)-1] == '/')
				    $listOfTrace[] = $val;
		  
        }
	}else{
		  $listOfTrace='';
    }
	
    
    return $listOfTrace;			 
}

//************************************************************************************
function KTBS_Get_Obsels_List($url)
{	 
    $cont = KTBS_Curl_Connect_Get($url);
	if(array_key_exists('obsels', $cont))
	{		
	      $contains = $cont['obsels'];
	}
	else
	{	 
	      $contains='';		  
	}
	return $contains;	
}

//*************************************************************************************

//                        KTBS POST FUNCTIONS

//*************************************************************************************
function KTBS_Create_DB($url, &$Base_Name)
 {
	 
	 $content=
'	 {
    "@id": "'.$Base_Name.'/",
    "@type": "Base",
	"label": "New Base"
}';

//Execute request;

	KTBS_Curl_Connect_Post($url, $content);   
 }

//*************************************************************************************
function KTBS_Create_Trace($url,$Trace_Name)
 {
	 
	 $content='	 {
   "@id": "'.$Trace_Name.'/",
    "@type": "StoredTrace",
    "hasModel": "http://liris.cnrs.fr/silex/2011/simple-trace-model/",
    "origin": "1970-01-01T00:00:00Z",
    "defaultSubject": "me"}';
//Execute request;
	KTBS_Curl_Connect_Post($url, $content);   
 }
//*************************************************************************************
function KTBS_Create_Obsel($url, $trace, $User, $Subject, $Value)
 {	 			 
            $content='{			
            "subject": "'.$Subject.'",
            "m:user": "'.$User.'",
			"m:value": "'.$Value.'",
			"beginDT": "", 
            "endDT": ""		    
        }';
		
	KTBS_Curl_Connect_Post($url, $content);   
 }

//*************************************************************************************
function KTBS_Count_Obsel($url, $trace){
$value=0;
$content='{
    "@id": "C'.$trace.'/",
    "@type": "ComputedTrace",
    "hasMethod": "sparql",
    "hasSource": [ "'.$trace.'/" ],
    "parameter": [ "sparql=    PREFIX : <http://liris.cnrs.fr/silex/2009/ktbs#>\nPREFIX m:  <http://liris.cnrs.fr/silex/2011/simple-trace-model/>\n\nCONSTRUCT {\n    [ a m:SimpleObsel ;\n      m:value ?nbo ;\n      :hasTrace <%(__destination__)s> ;\n      :hasBegin ?begin ;\n      :hasEnd ?end ;\n      :hasSourceObsel ?nbo ;\n    ] .\n} WHERE {\n    SELECT (count(?o) as ?nbo) (min(?b) as ?begin) (max(?e) as ?end) { ?o :hasTrace <%(__source__)s> ; :hasBegin ?b ; :hasEnd ?e} \n}\n" ]
}';
  //echo $content.'<p>';  
	KTBS_Curl_Connect_Post($url, $content);   
    $url2=$url.'C'.$trace.'/@obsels';
	
	$contains=KTBS_Get_Obsels_List($url2);
	if (!empty($contains)){
	 
	 foreach (array_keys($contains) as $key) {
		    
			$id = $contains[$key]["@id"];	
			$value= $contains[$key]["m:value"];
			
	}
	}

	// il faut supprimer par la suite ces variables
	$del=$url.'C'.$trace.'/';
    $c='';
   
//echo $del;
    Ktbs_Curl_Delete($del,$c);

	return $value;
	
 }
//*************************************************************************************

function KTBS_Transformation_filter($url, $source, $destination, $param)
{
$content='{
    "@id": "'.$destination.'/",
    "@type": "ComputedTrace",
    "hasMethod": "filter",
    "hasSource": [ "'.$source.'/" ],
    "parameter": [ "'.$param.'" ]
}';
KTBS_Curl_Connect_Post($url, $content);   

}
//*************************************************************************************

function KTBS_Transformation_fiteruser($url, $source, $destination, $user)
{
$url2=$url.$destination.'/';

$content='
@prefix : <http://liris.cnrs.fr/silex/2009/ktbs#> .
@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
@prefix skos: <http://www.w3.org/2004/02/skos/core#> .
@prefix xml: <http://www.w3.org/XML/1998/namespace> .
@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .

<> :contains <'.$destination.'/> .

<'.$destination.'/> a :ComputedTrace ;
    :hasSource <'.$source.'/> ;
    :hasMethod :filter ;
    :hasParameter "bgp=?obs <http://liris.cnrs.fr/silex/2011/simple-trace-model/user> ?usr . FILTER(?usr=\"'.$user.'\")" ;
.';

KTBS_Curl_Connect_Post_turtle($url, $content);   
	 
	 
	 
	 
}
//*************************************************************************************
function KTBS_Transformation_fiterafter($url, $source, $destination, $param)
{
$url2=$url.$destination.'/';

$content='
@prefix : <http://liris.cnrs.fr/silex/2009/ktbs#> .
@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
@prefix skos: <http://www.w3.org/2004/02/skos/core#> .
@prefix xml: <http://www.w3.org/XML/1998/namespace> .
@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .
@prefix : <http://liris.cnrs.fr/silex/2009/ktbs#> .

<> :contains <'.$destination.'/> .

<'.$destination.'/> a :ComputedTrace ;
    :hasSource <'.$source.'/> ;
    :hasMethod :filter ;
    :hasParameter "after='.$param.'" 
.
';
KTBS_Curl_Connect_Post_turtle($url, $content);   
}
//*************************************************************************************
 function KTBS_Transformation_fusion($url, $source1,$source2, $destination)
 {
$content='{
    "@id": "'.$destination.'/",
    "@type": "ComputedTrace",
    "hasMethod": "fusion",
    "hasSource": [ "'.$source1.'/", "'.$source2.'/" ]
}';
KTBS_Curl_Connect_Post($url, $content);   

 }
//*************************************************************************************

//*************************************************************************************

function KTBS_Execute_Transformation($url, $sequence)
 {
   $vv='';
   
  //***************************************************************
  // TRANSFORM DIAGRAM TO TEXT LINES: this allow to execute transformation
  //***************************************************************
   $nodes = array();
   $relations= array();



   $nodes = $sequence["nodeDataArray"];

   $relations = $sequence["linkDataArray"];

   foreach ($relations as $relation) {
         $Source=$relation["from"];  

         foreach ($nodes as $node) {
   
             if ($node["key"]==$Source) {  
                $Tsource=$node["text"]; 
                break;
            }
         }
    
         $Source=$relation["to"];  
   
         foreach ($nodes as $node) {
   
            if ($node["key"]==$Source) {  
                $Tdestination=$node["text"]; 
                break;
            }
         }


       
  //***************************************************************
  // GET TRANSFORMATION PARAMETERS
  //***************************************************************    
      
          $operatorAll= explode(":", $relation["text"]);
          $operator=$operatorAll[0];
         
  //***************************************************************
        

	      if ($operator=='filter'){
	           $items=explode("=", $operatorAll[1]);
	           $Kind=$items[0];
	           $Value=$items[1];
 
	           $source=$Tsource;
               $destination=$Tdestination;

	           if ($Kind=='after')
	               KTBS_Transformation_fiterafter($url, $source, $destination, $Value);

	           if ($Kind=='before')
	               KTBS_Transformation_filter($url, $source, $destination, $Value);

		       if ($Kind=='user') 
		 
			       KTBS_Transformation_fiteruser($url, $source, $destination, $Value);
			   
			   
			   $val=KTBS_Count_Obsel($url, $destination);
	          $vv=$vv.$destination."=".$val."\n";
	      }
	  
  //***************************************************************

	      if ($operator=='fusion'){	
              // echo '<br> Pour la fusion: '.$operatorAll[2].'</br>';
	    
	          $source1=$Tsource;
	          $source2=$operatorAll[1];
              $destination=$Tdestination;
	   
	          KTBS_Transformation_fusion($url, $source1,$source2, $destination, $operator);	   
	          if ($_SESSION['base'] !='Indicators') {
			      $val=KTBS_Count_Obsel($url, $destination);
	              $vv=$vv.$destination."=".$val."\n";
			   }
			   
	      }
	 
	      if ($operator=='equation'){	
              $_SESSION['equation']=''; 
	   	      $_SESSION['CurrentIndicatorName']='';

	   	      $_SESSION['equation']=$operatorAll[1];
	   	    //  echo "<br>".$operatorAll[1];
	   	      $_SESSION['CurrentIndicatorName']=$Tdestination;
	   	    //  echo "<br>".$Tdestination;
	   	      

	   	      
	      }

	      if ($operator=='perday'){	
               
	   	      
	      }
	 
	
	}
	return $vv;
 }

 function ComputeEquation() {

 require_once('../lib/evalmath.class.php');
   
   
   $variable=$_SESSION['variab'];
   $equation=$_SESSION['equation'];

   $equation=$variable."\n".$equation;
   //$_SESSION['result']=$equation;
   
   
   $equation = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $equation);
   $equation=str_replace(' ','',$equation);
   $m = new EvalMath;
   $Val='';
   $m->suppress_errors = true;
   $Tch    =   explode("\n",$equation);
   foreach ($Tch as $value){
      $X =   explode("=",$value);
      $res=$m->evaluate($value);
      if ($X[0]!='')
         $Val=$Val.$X[0]."=".$res."\n";
   }
   $Val = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $Val);
   $Val=str_replace(' ','',$Val);
   $_SESSION['result']=ltrim($Val);
   $_SESSION['variab']=ltrim($Val);
   $res=$_SESSION['result'];

  // $_SESSION['variab']=ltrim($_REQUEST['variab']);
  // $_SESSION['equation']=ltrim($_REQUEST['equation']);       
   //echo("<script>location ='../Index.php';</script>") ;  
  return $res;

 }
 
//*************************************************************************************

function KTBS_Create_Model($url){

$Icontent='
@prefix : <http://liris.cnrs.fr/silex/2009/ktbs#> .
@prefix skos: <http://www.w3.org/2004/02/skos/core#> .
@prefix xsd:  <http://www.w3.org/2001/XMLSchema#> .

<.> :contains <IndicatorModel> .

<IndicatorModel> a :TraceModel ;
    :hasUnit :millisecond .

<IndicatorModel#Indicator> a :ObselType .
<IndicatorModel#ITransformation> a :ObselType .
<IndicatorModel#Ivalues> a :ObselType .

<IndicatorModel#name> a :AttributeType ;
    skos:prefLabel "name" ;
    :hasAttributeDomain <IndicatorModel#Indicator> ;
    :hasAttributeRange xsd:string .

<IndicatorModel#equation> a :AttributeType ;
    skos:prefLabel "equation" ;
    :hasAttributeDomain <IndicatorModel#Indicator> ;
    :hasAttributeRange xsd:string .

<IndicatorModel#description> a :AttributeType ;
    skos:prefLabel "description" ;
    :hasAttributeDomain <IndicatorModel#Indicator> ;
    :hasAttributeRange xsd:string .


<IndicatorModel#identifier> a :AttributeType ;
    skos:prefLabel "identifier" ;
    :hasAttributeDomain <IndicatorModel#Ivalues> ;
    :hasAttributeRange xsd:string .

<IndicatorModel#values> a :AttributeType ;
    skos:prefLabel "values" ;
    :hasAttributeDomain <IndicatorModel#Ivalues> ;
    :hasAttributeRange xsd:string .

<IndicatorModel#vtime> a :AttributeType ;
    skos:prefLabel "values" ;
    :hasAttributeDomain <IndicatorModel#Ivalues> ;
    :hasAttributeRange xsd:string .

<IndicatorModel#tname> a :AttributeType ;
    skos:prefLabel "tname" ;
    :hasAttributeDomain <IndicatorModel#ITransformation> ;
    :hasAttributeRange xsd:string .

<IndicatorModel#tsequence> a :AttributeType ;
    skos:prefLabel "tname" ;
    :hasAttributeDomain <IndicatorModel#ITransformation> ;
    :hasAttributeRange xsd:string .


<IndicatorModel#equation> a :AttributeType ;
    skos:prefLabel "equation" ;
    :hasAttributeDomain <IndicatorModel#Indicator> ;
    :hasAttributeRange xsd:string .

<IndicatorModel#description> a :AttributeType ;
    skos:prefLabel "description" ;
    :hasAttributeDomain <IndicatorModel#Indicator> ;
    :hasAttributeRange xsd:string .

<IndicatorModel#hasIndicator> a :RelationType ;
    :hasRelationDomain <IndicatorModel#Ivalues>;
    :hasRelationRange <IndicatorModel#Indicator> .

<IndicatorModel#hasTransformation> a :RelationType ;
    :hasRelationDomain <IndicatorModel#Indicator>;
    :hasRelationRange <IndicatorModel#ITransformation> .


<IndicatorModel#HasIndicator> a :RelationType ;
    :hasRelationDomain <IndicatorModel#IndicatorValues>;
    :hasRelationRange <IndicatorModel#Indicator> .

<IndicatorModel#HasTransformation> a :RelationType ;
    :hasRelationDomain <IndicatorModel#Indicator>;
    :hasRelationRange <IndicatorModel#Transformation> .';

KTBS_Curl_Connect_Post_turtle($url, $Icontent); 

}
//*************************************************************************************
function KTBS_Create_Indicator($url, $Name,$ISubject,$Iequation, $IvalueId, $value,$ItimeVal, $ITransformationName, $transformation)
 {	 
      
// Step1: create the indicator model:
//*************************************************************************************
KTBS_Create_Model($url);


//*************************************************************************************
// Step2: Create the related trace: its name is the indicator name

$content='
@prefix : <http://liris.cnrs.fr/silex/2009/ktbs#> .

<> :contains <'.$Name.'/> .

<'.$Name.'/>
    a :StoredTrace;
    :hasModel <http://localhost:8001/IndicatorModel> ;
    :hasOrigin "1970-01-01T00:00:00Z".';

KTBS_Curl_Connect_Post_turtle($url, $content); 

//*************************************************************************************
// Step3: Create obsels related to this trace: we create three obsels: indicator, indicatorvalues and indicatortransformation

// il faut corriger la partie equation : trouver le moyen pourquoi il n'insére par l'equation correctement
$url=$url.$Name.'/';


$content='@prefix : <http://liris.cnrs.fr/silex/2009/ktbs#> .
@prefix m: <http://localhost:8001/Indicators/IndicatorModel#> .

<Obsel_Indicator_'.$Name.'> a m:Indicator ;
    :hasTrace <> ;
     m:name "Obsel_Indicator_'.$Name.'";
     m:equation "xxx";
     m:description "'.$ISubject.'".';

KTBS_Curl_Connect_Post_turtle($url, $content); 

// Mettre par la suite les bonnes valeurs identifiant, valeurs et timeval

$content='
@prefix : <http://liris.cnrs.fr/silex/2009/ktbs#> .
@prefix m: <http://localhost:8001/Indicators/IndicatorModel#> .

<Obsel_Values_'.$Name.'> a m:IndicatorValues ;
    :hasTrace <> ;
     m:Identifier "Identifier";
     m:Values "Display error: NULL for the moment";
     m:TimeValue "'.$ItimeVal.'".';

KTBS_Curl_Connect_Post_turtle($url, $content); 


// La transformation

$content='
@prefix : <http://liris.cnrs.fr/silex/2009/ktbs#> .
@prefix m: <http://localhost:8001/Indicators/IndicatorModel#> .

<Obsel_Transformation_'.$Name.'> a m:IndicatorValues ;
    :hasTrace <> ;
     m:tname "Obsel_Transformation_'.$Name.'";
     m:tsequence "Display error: Null for the moment".';
    
KTBS_Curl_Connect_Post_turtle($url, $content); 

//*************************************************************************************
// Create related relations between indicator values and transformtions

$content='

@prefix : <http://liris.cnrs.fr/silex/2009/ktbs#> .
@prefix m: <http://localhost:8001/Indicators/IndicatorModel#> .

<Rel_Values_Indicator> a m:HasIndicator ;
    :hasTrace <> ;
    m:hasRelationOrigin "Obsel_Values_'.$Name.'";
    m:hasRelationDestination  "Obsel_Indicator_'.$Name.'".';

KTBS_Curl_Connect_Post_turtle($url, $content); 


$content='

@prefix : <http://liris.cnrs.fr/silex/2009/ktbs#> .
@prefix m: <http://localhost:8001/Indicators/IndicatorModel#> .

<Rel_Indicator_Transformation> a m:hasTransformation ;
    :hasTrace <> ;
    m:hasRelationOrigin "Obsel_Indicator_'.$Name.'";
    m:hasRelationDestination  "Obsel_Transformation_'.$Name.'".';

KTBS_Curl_Connect_Post_turtle($url, $content); 


 }

//************************************************************************************* 
?>

