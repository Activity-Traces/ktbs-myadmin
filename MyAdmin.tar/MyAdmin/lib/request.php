<?php
//****************************************************************************************

session_start();

//****************************************************************************************

$Choice=$_REQUEST['Action'];
require_once("../config/config.php");
require_once("../lib/service.php");

//****************************************************************************************

if ($Choice=='AddBD'){
   $Base_Name=$_REQUEST['BaseName'];    
   KTBS_Create_DB($ktbs_url, $Base_Name);
   echo "<b>New base added.</b>";
   echo("<script>parent.menu.location='../view/LeftMenue.php';</script>") ;
}
//****************************************************************************************

if ($Choice=='DelBD'){
   $content='';
   $url=$ktbs_url.$_REQUEST['BaseName'].'/';      
   Ktbs_Curl_Delete($url,$content);
   echo "<b>".$_REQUEST['BaseName']." Deleted.</b>";
   echo("<script>parent.menu.location='../view/LeftMenue.php';</script>") ;
}
//****************************************************************************************

if ($Choice=='AddTrace'){
   $Base_Name=$_REQUEST['BaseName'];    
   $Trace_Name=$_REQUEST['TraceName'];    
   $url=$ktbs_url.$Base_Name.'/'; 
   KTBS_Create_Trace($url, $Trace_Name);
   echo "<b>".$Trace_Name."</b> created";
   echo("<script>parent.menu.location='../view/LeftMenue.php';</script>") ;
}

//****************************************************************************************

if ($Choice=='AddObsel'){
   $Base_Name=$_REQUEST['BaseName'];    
   $Trace_Name=$_REQUEST['TraceName'];    
   
   $OUser=$_REQUEST['ouser'];    
   $OSubject=$_REQUEST['osubject'];    
   $OValue=$_REQUEST['oval'];    

   $url=$ktbs_url.$Base_Name.'/'.$Trace_Name.'/'; 
   KTBS_Create_Obsel($url, $Trace_Name, $OUser, $OSubject, $OValue);
   echo("<script>location='../view/ViewTrace.php?TraceName=".$Trace_Name."&TraceBase=".$Base_Name."';</script>") ;  
}
//****************************************************************************************
// manage transformations and indicators
//****************************************************************************************
if (isset($_REQUEST['ExecuteTransformation'])){
   
   $Base_Name=$_REQUEST['BaseName'];
   $_SESSION['base']=$Base_Name;
   
   $TransformationJson=$_REQUEST['DiagramText'];
   $_SESSION['TransformationJson']=$TransformationJson;

   
   $diagram = json_decode( $TransformationJson, true);


   
   $url=$ktbs_url.$Base_Name.'/';
   if (isset( $diagram)){
      $x=KTBS_Execute_Transformation($url, $diagram);
      
      $_SESSION['variab']=$x;
      $_SESSION['diagram']= $_REQUEST['DiagramText'];

      //echo "<br>". $_SESSION['equation'];
      //echo "<br>". $_SESSION['CurrentIndicatorName'];
      $res=ComputeEquation();
     // echo "<br>". $res;
             
   }
   
  //echo("<script>location ='../Index.php';</script>") ;

}

//****************************************************************************************

if (isset($_REQUEST['ExecuteSPARQL'])){
   
   $Base_Name=$_REQUEST['BaseName'];       
   $Transformationql=$_REQUEST['transformationql'];
   ltrim($Transformation);
   $_SESSION['base']= $Base_Name;
   $_SESSION['sparql']= ltrim($Transformationql);
   
   $url=$ktbs_url.$Base_Name.'/';
      
   if (isset( $Transformationql))
       KTBS_Curl_Connect_Post($url, $Transformationql);

   echo("<script>location ='../Index.php';</script>") ;
}    
//****************************************************************************************
  
        
if($Choice=="ViewIndicator"){
 $ch=$_REQUEST['ch'];          
 echo("<script>location ='../lib/plot.php?ch=".$ch."' ;</script>") ;

}


//****************************************************************************************

if ($Choice=="SaveIndicators"){
     
   $Base_Name='Indicators';  
   
   $url=$ktbs_url.$Base_Name.'/';
   
   // Information Related to Object2 obseltype1: Indicator

   $IName= $_REQUEST['IndicatorName'];    
   $ISubject=$_REQUEST['IndicatorSubject'];
   $Iequation=$_SESSION['equation'];
   

   // Information Related to  obseltype2: Indicator Values

   $IvalueId='Values_'.$IName; // rajouter une valeur aléatoire   
   $Ivalue=$_SESSION['result'];
   $ItimeVal='NULL';

   // Information Related to  obseltype3: Transformation
   $ITransformationName='Trans_'.$IName;
   //$ITransformation=$_SESSION['diagram'];
  // encore du travail pour sauvgarder la transforfmation
   $Isequence='NULL for the moment';
  // preparing data    

   //$transformation = str_replace(";"," + ",$ITransformation);
   //$transformation=preg_replace('/\s{2,}/\n\r', ' ', $ITransformation);

   $equation = str_replace("\n"," ",$Iequation);
   $equation = str_replace("\r"," ",$Iequation);
   
   $value = str_replace("\n"," ",$Ivalue);
   $value = str_replace("\r"," ",$Ivalue);
   ltrim($Isequence);
   ltrim($equation);
   ltrim($value);
   
   
   $url=$ktbs_url.$Base_Name.'/';   
   
   KTBS_Create_Indicator($url, $IName,$ISubject,$equation, $IvalueId, $value,$ItimeVal, $ITransformationName, $Isequence);
      echo("<script>location ='../Index.php';</script>") ;
  // echo("<script>location='../view/ViewTrace.php?TraceName=".$Indicator_Trace."&TraceBase=".$Indicator_Base."';</script>") ;
}

//****************************************************************************************

if (isset($_REQUEST['ComputeEquation'])){
   require_once('../lib/evalmath.class.php');
   
   
   $variable=$_REQUEST['variab'];
   $equation=$_REQUEST['equation'];
   $equation=$variable."\n".$equation;
   //$_SESSION['result']=$equation;
   
   
   $equation = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $equation);
   $equation=str_replace(' ','',$equation);
   $m = new EvalMath;
   $Val='';
   $m->suppress_errors = true;
   $Tch    =   explode("\n",$equation);
   foreach ($Tch as $value){
      $X =   explode("=",$value);
      $res=$m->evaluate($value);
      if ($X[0]!='')
         $Val=$Val.$X[0]."=".$res."\n";
   }
   $Val = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $Val);
   $Val=str_replace(' ','',$Val);
   $_SESSION['result']=ltrim($Val);
   $_SESSION['variab']=ltrim($Val);
   $_SESSION['variab']=ltrim($_REQUEST['variab']);
   $_SESSION['equation']=ltrim($_REQUEST['equation']);       
   echo("<script>location ='../Index.php';</script>") ;  
}
if (isset($_REQUEST['init'])){
   
   $_SESSION['transformation']="";
   $_SESSION['result']="";
   $_SESSION['variab']="";
   $_SESSION['variab']="";
   $_SESSION['equation']="";
   $_SESSION['indicatorview']="";
   //echo("<script>location ='../Index.php';</script>") ;
}
?>