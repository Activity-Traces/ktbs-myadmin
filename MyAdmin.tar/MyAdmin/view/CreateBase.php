<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>KTBS-MyADMIN</title>
</head>
<?php
require_once("../config/config.php");
require_once("../lib/service.php");
 $id=KTBS_Get_info($ktbs_url);

 
?>

<h3>KTBS global informations:</h3><p>

<body >
<table align="left" border="0" cellpadding="1" cellspacing="1">
	
		<tr>
			<td><b>KTBS Url </b></td>
			<td>: <?php echo $id[0]; ?></td>
		</tr>
		<tr>
			<td><b>User Name </b></td>
            <td>: <?php echo $user; ?></td>
		</tr>
		<tr>
			<td><b>Context </b></td>
			<td>: <?php echo $id[1]; ?></td>
		</tr>
		<tr>
			<td><b>Type </b></td>
			<td>: <?php echo $id[2]; ?></td>
		</tr>
		<tr>
			<td><b>Version </b></td>
			<td>: <?php echo $id[3]; ?></td>
		</tr>
	
</table>

<br><br><br><br><br><br><br>
<h3><hr></hr></h3>
<br><br>

<form id="form1" name="form1" method="post" action="../lib/request.php?Action=AddBD">
   <label for="textfield">Create a New KTBS Base</label>
   <input type="text" name="BaseName" id="BaseName"> 
   <input type="submit" name="Create" id="Create" value="    Create    ";">
</form>
<br>
<h3>
<hr></hr></h3>

<form id="form1" name="form1" method="post" action="../lib/request.php?Action=DelBD">
   <label for="textfield">Delete existing KTBS Base:</label>
   <select name="BaseName"
		   
<?php
  
    require_once("../config/config.php");
    require_once("../lib/service.php");

    $Bases=KTBS_Get_DataBase_List($ktbs_url);
    for($i=-1;$i<count($Bases); $i++){
		$name=$Bases[$i];
		$name=substr($name,0,strlen($name)-1);
		echo '<option value='.$name.'>'.$name.'</option>';
     }
?>

   </select>
   <input type="submit" name="Delete" id="Delete" value="    Delete    "
          onclick="return(confirm('Do you want to delete this DataBase?'));">
</form>
</body>
</html>
