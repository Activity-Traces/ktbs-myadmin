<!-- **********************************************************************-->
<!-- **********************************************************************-->

<head>
<script type="text/javascript">
  function switchInfoPerso(x)
		{
			divInfo = document.getElementById(x);
			if (divInfo.style.display == 'none')
			    divInfo.style.display ='block';else divInfo.style.display = 'none';
		}	
</script>
</head>

<!-- **********************************************************************-->
<!-- **********************************************************************-->

<?php
session_start();


//****************************************************************************
// global variales uses to display obsels
//****************************************************************************

require_once("../config/config.php");
require_once("../lib/service.php");
require_once('help.php');


if   (isset($_GET["TraceName"]))
        $Trace=$_GET["TraceName"];
      

if   (isset($_GET["TraceBase"]))	
        $Base=$_GET["TraceBase"];

	  
	  
//****************************************************************************

$url=$ktbs_url.$Base.'/'.$Trace.'/';
$id=KTBS_Get_Trace_Info($url)

?>

<a href="javascript: switchInfoPerso('tracedetails');">View Related information about this trace</a> 
<div id="tracedetails" style="display: none;"><br>

<table align="left" border="0" cellpadding="1" cellspacing="1" ">
	<tbody>
		<tr>
			<td><b>Trace Name</b></td>
			<td>: <?php echo $Trace; ?></td>
		</tr>
		<tr>
			<td><b>Id</b></td>
			<td>: <?php echo $id[0]; ?></td>
		</tr>
		<tr>
			<td><b>Type </b></td>
			<td>: <?php echo $id[1]; ?></td>
		</tr>
		<tr>
			<td ><b>Has Model </b></td>
			<td>: <?php echo $id[2]; ?></td>
		</tr>
		<tr>
			<td ><b>Origin </b></td>
			<td>: <?php echo $id[3]; ?></td>
			
		</tr>
		<tr>
			<td><b>Default Subject </b></td>
			<td>: <?php if (isset($id[4])) echo $id[4]; ?></td>
			
		</tr>
		<tr>
			<td><b>In Base </b></td>
			<td>: <?php echo $id[5]; ?></td>
			
		</tr>
		<tr>
			<td><b>Context </b></td>
			<td>: <?php if(isset( $id[6])) echo $id[6]; ?></td>
			
		</tr>
	</tbody>
</table>
<h3>
<br><br><br><br><br><br><br><br></div>


<?php

//****************************************************************************
// 
// connect ot ktbs, get obsels list,then preview them
//****************************************************************************

echo '
<hr></hr>
        <form id="form1" name="form1" method="post"
		action="../lib/request.php?Action=AddObsel&BaseName='.$Base.'&TraceName='.$Trace.'">
        <label for="textfield">Add a New Obsel to this trace (modify default values): </label>   
   		<table border="0">
				<tr><td>User :</td><td><input name="ouser" type="text" value="user0"/></td></tr>
				<tr><td>Subject :</td><td><input name="osubject" type="text" value = "me"/></td></tr>
				<tr><td>Value :</td><td><input name="oval" type="text" value = "value0"/></td></tr>
				
		</table>
		<br>
		 <input type="submit" name="Create" id="Create" value=" Create" > 
</form>';

echo"<hr></hr>";


$url=$ktbs_url.$Base.'/'.$Trace.'/'.'@obsels';
$c=KTBS_Get_Obsels_List($url);

$value='';

if (!empty($c)){
				Trace_title();
				View_Obsels_List($c,$Trace);
}

else
{
		echo "OBSELS: NULL";
		
}
	