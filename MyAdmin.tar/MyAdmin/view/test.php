<?php
session_start();


//****************************************************************************
// global variales uses to display obsels
//****************************************************************************

require_once("../config/config.php");
require_once("../lib/service.php");
require_once('help.php');



        $Trace="trace1";
     
        $Base="base1";

$url=$ktbs_url.$Base.'/'.$Trace.'/@stats';

echo $url;

$cont = KTBS_Curl_Connect_Get($url);
	


	if(array_key_exists('ns1:obselCount', $cont))
	{		
	      $contains = $cont['ns1:obselCount'];
	}
	else
	{	 
	      $contains='VIDE';		  
	}
	echo $contains;	

	//print_r($cont);







	foreach (array_keys($cont) as $key) {
		if(array_key_exists('ns1:obselCount', $cont)){
		    	$val = $cont[$key]["ns1:obselCount"];
		
			    echo $val;

      }
    }




?>