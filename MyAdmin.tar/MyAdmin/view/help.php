<?php
//****************************************************************************

function sparql_help(){
    echo '
<body>
<div class="highlight-sparql" style="font-size: 16px; box-sizing: border-box; border: 1px solid rgb(225, 228, 229); padding: 0px; overflow-x: auto; margin: 1px 0px 24px; color: rgb(64, 64, 64); font-family: Lato, proxima-nova, "Helvetica Neue", Arial, sans-serif; background: rgb(255, 255, 255);">
<div class="highlight" style="box-sizing: border-box; border: none; padding: 0px; overflow-x: auto; margin: 0px; background: none;">
<pre style="box-sizing: border-box; font-family: Consolas, "Andale Mono WT", "Andale Mono", "Lucida Console", "Lucida Sans Typewriter", "DejaVu Sans Mono", "Bitstream Vera Sans Mono", "Liberation Mono", "Nimbus Mono L", Monaco, "Courier New", Courier, monospace; font-size: 12px; margin-top: 0px; margin-bottom: 0px; padding: 12px; line-height: 1.5; overflow: auto;">
<span style="line-height: 1.5; background-color: initial;">{
</span><span style="line-height: 1.5; background-color: initial;">   </span><span class="nt" style="line-height: 1.5; box-sizing: border-box; color: navy; background-color: initial;">&quot;@id&quot;</span><span class="p" style="line-height: 1.5; box-sizing: border-box; background-color: initial;">:</span><span style="line-height: 1.5; background-color: initial;"> </span><span class="s2" style="line-height: 1.5; box-sizing: border-box; color: rgb(221, 17, 68); background-color: initial;">&quot;joinRelated1/&quot;</span><span class="p" style="line-height: 1.5; box-sizing: border-box; background-color: initial;">,
</span><span style="line-height: 1.5; background-color: initial;">    </span><span class="nt" style="line-height: 1.5; box-sizing: border-box; color: navy; background-color: initial;">&quot;@type&quot;</span><span class="p" style="line-height: 1.5; box-sizing: border-box; background-color: initial;">:</span><span style="line-height: 1.5; background-color: initial;"> </span><span class="s2" style="line-height: 1.5; box-sizing: border-box; color: rgb(221, 17, 68); background-color: initial;">&quot;ComputedTrace&quot;</span><span class="p" style="line-height: 1.5; box-sizing: border-box; background-color: initial;">,
</span><span style="line-height: 1.5; background-color: initial;">    </span><span class="nt" style="line-height: 1.5; box-sizing: border-box; color: navy; background-color: initial;">&quot;hasMethod&quot;</span><span class="p" style="line-height: 1.5; box-sizing: border-box; background-color: initial;">:</span><span style="line-height: 1.5; background-color: initial;"> </span><span class="s2" style="line-height: 1.5; box-sizing: border-box; color: rgb(221, 17, 68); background-color: initial;">&quot;sparql&quot;</span><span class="p" style="line-height: 1.5; box-sizing: border-box; background-color: initial;">,
</span><span style="line-height: 1.5; background-color: initial;">    </span><span class="nt" style="line-height: 1.5; box-sizing: border-box; color: navy; background-color: initial;">&quot;hasSource&quot;</span><span class="p" style="line-height: 1.5; box-sizing: border-box; background-color: initial;">:</span><span style="line-height: 1.5; background-color: initial;"> </span><span class="p" style="line-height: 1.5; box-sizing: border-box; background-color: initial;">[</span><span style="line-height: 1.5; background-color: initial;"> </span><span class="s2" style="line-height: 1.5; box-sizing: border-box; color: rgb(221, 17, 68); background-color: initial;">&quot;t01/&quot;</span><span style="line-height: 1.5; background-color: initial;"> </span><span class="p" style="line-height: 1.5; box-sizing: border-box; background-color: initial;">],
</span><span class="nt" style="line-height: 1.5; box-sizing: border-box; color: navy; background-color: initial;">    &quot;parameter&quot;</span><span class="p" style="line-height: 1.5; box-sizing: border-box; background-color: initial;">:</span><span style="line-height: 1.5; background-color: initial;"> </span><span class="p" style="line-height: 1.5; box-sizing: border-box; background-color: initial;">[</span><span style="line-height: 1.5; background-color: initial;"> </span><span class="s2" style="line-height: 1.5; box-sizing: border-box; color: rgb(221, 17, 68); background-color: initial;">&quot;sparql= </span><span class="kr" style="line-height: 1.5; box-sizing: border-box; font-weight: bold; background-color: initial;">PREFIX</span><span class="w" style="line-height: 1.5; box-sizing: border-box; color: rgb(187, 187, 187); background-color: initial;"> </span><span class="nt" style="line-height: 1.5; box-sizing: border-box; color: navy; background-color: initial;">:</span><span class="w" style="line-height: 1.5; box-sizing: border-box; color: rgb(187, 187, 187); background-color: initial;"> </span><span class="no" style="line-height: 1.5; box-sizing: border-box; color: teal; background-color: initial;">&lt;http://liris.cnrs.fr/silex/2009/ktbs#&gt;
</span><span class="kr" style="line-height: 1.5; box-sizing: border-box; font-weight: bold; background-color: initial;">PREFIX</span><span class="w" style="line-height: 1.5; box-sizing: border-box; color: rgb(187, 187, 187); background-color: initial;"> </span><span class="nt" style="line-height: 1.5; box-sizing: border-box; color: navy; background-color: initial;">m:</span><span class="w" style="line-height: 1.5; box-sizing: border-box; color: rgb(187, 187, 187); background-color: initial;">  </span><span class="no" style="line-height: 1.5; box-sizing: border-box; color: teal; background-color: initial;">&lt;http://liris.cnrs.fr/silex/2011/simple-trace-model/&gt;
</span><span class="kr" style="line-height: 1.5; box-sizing: border-box; font-weight: bold; background-color: initial;">
CONSTRUCT</span><span class="w" style="line-height: 1.5; box-sizing: border-box; color: rgb(187, 187, 187); background-color: initial;">&nbsp;</span><span class="p" style="line-height: 1.5; box-sizing: border-box; background-color: initial;">{
</span><span class="w" style="line-height: 1.5; box-sizing: border-box; color: rgb(187, 187, 187); background-color: initial;">  </span><span class="p" style="line-height: 1.5; box-sizing: border-box; background-color: initial;">[</span><span class="w" style="line-height: 1.5; box-sizing: border-box; color: rgb(187, 187, 187); background-color: initial;"> </span><span class="kr" style="line-height: 1.5; box-sizing: border-box; font-weight: bold; background-color: initial;">a</span><span class="w" style="line-height: 1.5; box-sizing: border-box; color: rgb(187, 187, 187); background-color: initial;"> </span><span class="nt" style="line-height: 1.5; box-sizing: border-box; color: navy; background-color: initial;">m:SimpleObsel</span><span class="w" style="line-height: 1.5; box-sizing: border-box; color: rgb(187, 187, 187); background-color: initial;"> </span><span class="p" style="line-height: 1.5; box-sizing: border-box; background-color: initial;">;
</span><span class="nt" style="line-height: 1.5; box-sizing: border-box; color: navy; background-color: initial;">      m:value</span><span class="w" style="line-height: 1.5; box-sizing: border-box; color: rgb(187, 187, 187); background-color: initial;"> </span><span class="nv" style="line-height: 1.5; box-sizing: border-box; color: teal; background-color: initial;">?value</span><span class="w" style="line-height: 1.5; box-sizing: border-box; color: rgb(187, 187, 187); background-color: initial;"> </span><span class="p" style="line-height: 1.5; box-sizing: border-box; background-color: initial;">;
</span><span class="nt" style="line-height: 1.5; box-sizing: border-box; color: navy; background-color: initial;">      :hasTrace</span><span class="w" style="line-height: 1.5; box-sizing: border-box; color: rgb(187, 187, 187); background-color: initial;"> </span><span class="no" style="line-height: 1.5; box-sizing: border-box; color: teal; background-color: initial;">&lt;%(__destination__)s&gt;</span><span class="w" style="line-height: 1.5; box-sizing: border-box; color: rgb(187, 187, 187); background-color: initial;"> </span><span class="p" style="line-height: 1.5; box-sizing: border-box; background-color: initial;">;</span></pre>
				<pre style="box-sizing: border-box; font-family: Consolas, "Andale Mono WT", "Andale Mono", "Lucida Console", "Lucida Sans Typewriter", "DejaVu Sans Mono", "Bitstream Vera Sans Mono", "Liberation Mono", "Nimbus Mono L", Monaco, "Courier New", Courier, monospace; font-size: 12px; margin-top: 0px; margin-bottom: 0px; padding: 12px; line-height: 1.5; overflow: auto;">
<span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);">      </span><span class="nt" style="box-sizing: border-box; color: navy;">:hasBegin</span><span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);"> </span><span class="nv" style="box-sizing: border-box; color: teal;">?begin</span><span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);"> </span><span class="p" style="box-sizing: border-box;">;</span>
<span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);">      </span><span class="nt" style="box-sizing: border-box; color: navy;">:hasEnd</span><span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);"> </span><span class="nv" style="box-sizing: border-box; color: teal;">?end</span><span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);"> </span><span class="p" style="box-sizing: border-box;">;</span>
<span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);">      </span><span class="nt" style="box-sizing: border-box; color: navy;">:hasSourceObsel</span><span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);"> </span><span class="nv" style="box-sizing: border-box; color: teal;">?o1</span><span class="p" style="box-sizing: border-box;">,</span><span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);"> </span><span class="nv" style="box-sizing: border-box; color: teal;">?o2</span><span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);"> </span><span class="p" style="box-sizing: border-box;">;</span>
<span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);">    </span><span class="p" style="box-sizing: border-box;">]</span><span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);"> </span><span class="p" style="box-sizing: border-box;">.</span>
<span class="p" style="box-sizing: border-box;">}</span><span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);"> </span><span class="kr" style="box-sizing: border-box; font-weight: bold;">WHERE</span><span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);"> </span><span class="p" style="box-sizing: border-box;">{</span>
<span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);">    </span><span class="nv" style="box-sizing: border-box; color: teal;">?o1</span><span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);"> </span><span class="nt" style="box-sizing: border-box; color: navy;">:hasBegin</span><span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);"> </span><span class="nv" style="box-sizing: border-box; color: teal;">?begin</span><span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);"> </span><span class="p" style="box-sizing: border-box;">.</span>
<span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);">    </span><span class="nv" style="box-sizing: border-box; color: teal;">?o2</span><span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);"> </span><span class="nt" style="box-sizing: border-box; color: navy;">:hasEnd</span><span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);"> </span><span class="nv" style="box-sizing: border-box; color: teal;">?end</span><span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);"> </span><span class="p" style="box-sizing: border-box;">;</span>
<span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);">        </span><span class="nt" style="box-sizing: border-box; color: navy;">m:hasRelatedObsel</span><span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);"> </span><span class="nv" style="box-sizing: border-box; color: teal;">?o1</span><span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);"> </span><span class="p" style="box-sizing: border-box;">.</span>
<span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);">    </span><span class="kr" style="box-sizing: border-box; font-weight: bold;">OPTIONAL</span><span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);"> </span><span class="p" style="box-sizing: border-box;">{</span><span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);"> </span><span class="nv" style="box-sizing: border-box; color: teal;">?o2</span><span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);"> </span><span class="nt" style="box-sizing: border-box; color: navy;">m:value</span><span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);"> </span><span class="nv" style="box-sizing: border-box; color: teal;">?value</span><span class="w" style="box-sizing: border-box; color: rgb(187, 187, 187);"> </span><span class="p" style="box-sizing: border-box;">}
]
</span>}</pre>
			</div>
		</div>
    
    ';
}
//****************************************************************************

function transformation_help(){
	
    echo '
	optype can be: after, before or user.<br><br>
	Examples:<br><br>
	filte (after=10010) trace1 to trace2;    (put ; at the end of line)<br>
	filte (user=alain) trace1 to trace2;<br>
	fusion trace1 and trace2 to trace3;<br>
	at the end of the sequence put "."<br>
	filte (user=alain) trace1 to trace2.<br>';
}

//****************************************************************************

function Trace_title(){
    echo "
    <p align='center'>
    <table border=0><tr align='center'>
    <td width='200'  bgcolor='#2686A6'><b><span style='font-size:10pt;'>
                          <font   face='Tahoma'> Obsel id
                          </font>
                          </span></b>
                          </td>
    
    <td width='150' bgcolor='#2686A6'><b><span style='font-size:10pt;'>
                          <font   face='Tahoma'>Type
                          </font>
                          </span></b>
                          </td>
						  
    <td width='150' bgcolor='#2686A6'><b><span style='font-size:10pt;'>
                          <font   face='Tahoma'>User
                          </font>
                          </span></b>
                          </td>
						  
    <td width='150' bgcolor='#2686A6'><b><span style='font-size:10pt;'>
                          <font   face='Tahoma'>Timestamp Begin
                          </font>
                          </span></b>
                          </td>
    <td width='250' bgcolor='#2686A6'><b><span style='font-size:10pt;'>
                          <font   face='Tahoma'>Timestamp End
                          </font>
                          </span></b>
                          </td>
    				  
    <td width='250' bgcolor='#2686A6'><b><span style='font-size:10pt;'>
                          <font   face='Tahoma'>Subject
                          </font>
                          </span></b>
                          </td>
                         
    <td width='250' bgcolor='#2686A6'><b><span style='font-size:10pt;'>
                          <font   face='Tahoma'>Value
                          </font>
                          </span></b>
                          </td>
                         
						 
                          ";
}

//****************************************************************************

function View_List_Obsels($id, $type, $user, $begin, $end, $beginDT, $endDT, $subject, $value )
{
 	if (!isset ($endDT)){
		$endDT="";
	}
    echo "<tr align='center'> 
           <td bgcolor='E6E6E6'><span style='font-size:10pt;'>
                          <font color='black' face='Tahoma'>".$id."
    					  </font>
    					  </span>
    					  </td>
           <td bgcolor='E6E6E6'><span style='font-size:10pt;'>
                          <font color='black' face='Tahoma'>".$type."
    					  </font>
    					  </span>
    					  </td>
						  
		   <td bgcolor='E6E6E6'><span style='font-size:10pt;'>
                          <font color='black' face='Tahoma'>".$user."
    					  </font>
    					  </span>
    					  </td>			  
           <td bgcolor='E6E6E6'><span style='font-size:10pt;'>
                          <font color='black' face='Tahoma'>".$begin."
    					  </font>
    					  </span>
    					  </td>
           <td bgcolor='E6E6E6'><span style='font-size:10pt;'>
                          <font color='black' face='Tahoma'>". $end."
    					  </font>
    					  </span>
    					  </td>
           
		       
		   <td bgcolor='E6E6E6'><span style='font-size:10pt;'>
                          <font color='black' face='Tahoma'>".$subject."
    					  </font>
    					  </span>
    					  </td>
           		   
		   <td bgcolor='E6E6E6'><span style='font-size:10pt;'>
                          <font color='black' face='Tahoma'>".$value."
    					  </font>
    					  </span>
    					  </td>           		
		   ";
    
}

//****************************************************************************

function Title_Indicator(){
    echo "
    <p align='center'>
    <table border=0><tr align='center'>
    <td width='200'  bgcolor='#2686A6'><b><span style='font-size:10pt;'>
                          <font   face='Tahoma'> Indicator id
                          </font>
                          </span></b>
                          </td>
    
    <td width='150' bgcolor='#2686A6'><b><span style='font-size:10pt;'>
                          <font   face='Tahoma'>Type
                          </font>
                          </span></b>
                          </td>
						  
    
						  
    <td width='150' bgcolor='#2686A6'><b><span style='font-size:10pt;'>
                          <font   face='Tahoma'>Name
                          </font>
                          </span></b>
                          </td>
    <td width='250' bgcolor='#2686A6'><b><span style='font-size:10pt;'>
                          <font   face='Tahoma'>Equation
                          </font>
                          </span></b>
                          </td>
    					  
    <td width='250' bgcolor='#2686A6'><b><span style='font-size:10pt;'>
                          <font   face='Tahoma'>Description
                          </font>
                          </span></b>
                          </td>
    <td width='250' bgcolor='#2686A6'><b><span style='font-size:10pt;'>
                          <font   face='Tahoma'>Begin
                          </font>
                          </span></b>
                          </td>
    
	<td width='250' bgcolor='#2686A6'><b><span style='font-size:10pt;'>
                          <font   face='Tahoma'>End
                          </font>
                          </span></b>
                          </td>
                         
    <td width='250' bgcolor='#2686A6'><b><span style='font-size:10pt;'>
                          <font   face='Tahoma'>Values
                          </font>
                          </span></b>
                          </td>



    <td width='250' bgcolor='#2686A6'><b><span style='font-size:10pt;'>
                          <font   face='Tahoma'>Time value
                          </font>
                          </span></b>
                          </td>     

    <td width='250' bgcolor='#2686A6'><b><span style='font-size:10pt;'>
                          <font   face='Tahoma'>Transformation
                          </font>
                          </span></b>
                          </td>
    
  <td width='250' bgcolor='#2686A6'><b><span style='font-size:10pt;'>
                          <font   face='Tahoma'>Sequence
                          </font>
                          </span></b>
                          </td>
                         
    <td width='250' bgcolor='#2686A6'><b><span style='font-size:10pt;'>
                          <font   face='Tahoma'>From
                          </font>
                          </span></b>
                          </td>

    <td width='250' bgcolor='#2686A6'><b><span style='font-size:10pt;'>
                          <font   face='Tahoma'>To
                          </font>
                          </span></b>
                          </td>                         
						 
                          ";
}
  
//****************************************************************************

function View_List_Indicators(
  $name,
  $equation,
  $description,
  $values,
  $timeval,
  $transformation,
  $sequence,
  $id,
  $type,
  $begin,
  $end,
  $from,
  $to)
  {
           echo "<tr align='center'> 
           <td bgcolor='E6E6E6'><span style='font-size:10pt;'>
                          <font color='black' face='Tahoma'>".$id."
    					  </font>
    					  </span>
    					  </td>
           <td bgcolor='E6E6E6'><span style='font-size:10pt;'>
                          <font color='black' face='Tahoma'>".$type."
    					  </font>
    					  </span>
    					  </td>
						  
           <td bgcolor='E6E6E6'><span style='font-size:10pt;'>
                          <font color='black' face='Tahoma'>".$name."
    					  </font>
    					  </span>
    					  </td>
           <td bgcolor='E6E6E6'><span style='font-size:10pt;'>
                          <font color='black' face='Tahoma'>". $equation."
    					  </font>
    					  </span>
    					  </td>
        		   
		   <td bgcolor='E6E6E6'><span style='font-size:10pt;'>
                          <font color='black' face='Tahoma'>".$description."
    					  </font>
    					  </span>
    					  </td>
     <td bgcolor='E6E6E6'><span style='font-size:10pt;'>
                          <font color='black' face='Tahoma'>".$begin."
                </font>
                </span>
                </td>
                     
       <td bgcolor='E6E6E6'><span style='font-size:10pt;'>
                          <font color='black' face='Tahoma'>".$end."
                </font>
                </span>
                </td>
        <td bgcolor='E6E6E6'><span style='font-size:10pt;'>
                          <font color='black' face='Tahoma'>".$values."
    					  </font>
    					  </span>
    					  </td>
           
		   
		   <td bgcolor='E6E6E6'><span style='font-size:10pt;'>
                          <font color='black' face='Tahoma'>".$timeval."
    					  </font>
    					  </span>
    					  </td>
              		   
		   <td bgcolor='E6E6E6'><span style='font-size:10pt;'>
                          <font color='black' face='Tahoma'>".$transformation."
    					  </font>
    					  </span>
    					  </td>
      <td bgcolor='E6E6E6'><span style='font-size:10pt;'>
                          <font color='black' face='Tahoma'>".$sequence."
                </font>
                </span>
                </td>
      <td bgcolor='E6E6E6'><span style='font-size:10pt;'>
                          <font color='black' face='Tahoma'>".$from."
                </font>
                </span>
                </td>
       <td bgcolor='E6E6E6'><span style='font-size:10pt;'>
                          <font color='black' face='Tahoma'>".$to."
                </font>
                </span>
                </td>
                   ";
}

//****************************************************************************

function View_Obsels_List($contains,$trace)
{
	$subject="";
	$beginDT="";
	$endDT="";
	$user="";
	$value="";
  if (!empty ($contains)){
		
	    foreach (array_keys($contains) as $key) {
		    
			$id = $contains[$key]["@id"];	
	        $type = $contains[$key]["@type"];	    			
			$begin= $contains[$key]["begin"];	
	        $end= $contains[$key]["end"];
			
			if (isset($contains[$key]["subject"]))
	           $subject = $contains[$key]["subject"];
			
			if (isset($contains[$key]["beginDT"]))   
	           $beginDT= $contains[$key]["beginDT"];
			   
			if (isset($contains[$key]["endDT"]))
			   $endDT = $contains[$key]["endDT"];		        
			
			if (isset($contains[$key]["m:user"]))
			   $user= $contains[$key]["m:user"];	        
			
			if (isset($contains[$key]["m:value"]))
			   $value= $contains[$key]["m:value"];
			   
		    View_List_Obsels($id, $type, $user, $begin, $end, $beginDT, $endDT, $subject, $value);           
	   }
	}
  }
//****************************************************************************

function View_Obsels_Indicator_List($contains,$trace)
{
  if (!empty ($contains)){
		
	    foreach (array_keys($contains) as $key) {
		    
			$id = $contains[$key]["@id"];	
	        $type = $contains[$key]["@type"];	    			
			$begin = $contains[$key]["begin"];	
	        $end= $contains[$key]["end"];	
	        $subject = $contains[$key]["subject"];			
	        $equation= $contains[$key]["m:equation"];
			$transformation = $contains[$key]["m:transformation"];		        
			$value= $contains[$key]["m:value"];
			View_List_Indicators($id, $type, $begin, $end, $subject, $equation, $transformation, $value);
	        											
		}
  }
}
//****************************************************************************

?>
