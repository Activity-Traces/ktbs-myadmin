
<table border="0" cellpadding="2" cellspacing="2">
<tr>
<td><a href='../lib/request.php?Action=ViewIndicator&ch=13'><img src='../imgs/p1.PNG' alt='' title='' border=0 width=105 height=98></a></td>
<td><a href='../lib/request.php?Action=ViewIndicator&ch=12'><img src='../imgs/p2.PNG' alt='' title='' border=0 width=105 height=98></a> </td>
<td><a href='../lib/request.php?Action=ViewIndicator&ch=11'><img src='../imgs/p3.PNG' alt='' title='' border=0 width=105 height=98></a></td>
<td><a href='../lib/request.php?Action=ViewIndicator&ch=1'><img src='../imgs/l0.PNG' alt='' title='' border=0 width=105 height=98></a></td>
<td><a href='../lib/request.php?Action=ViewIndicator&ch=3'><img src='../imgs/l1.PNG' alt='' title='' border=0 width=105 height=98></a></td>
<td><a href='../lib/request.php?Action=ViewIndicator&ch=2'><img src='../imgs/l2.PNG' alt='' title='' border=0 width=105 height=98 style='border:#808080 1px solid'></a></td>
</tr>
<tr>
<td><a href='../lib/request.php?Action=ViewIndicator&ch=5' ><img src='../imgs/l3.PNG' alt='' title='' border=0 width=105 height=98></td>
<td><a href='../lib/request.php?Action=ViewIndicator&ch=6' ><img src='../imgs/l4.PNG' alt='' title='' border=0 width=105 height=98></a></td>
<td><a href='../lib/request.php?Action=ViewIndicator&ch=9' ><img src='../imgs/l5.PNG' alt='' title='' border=0 width=105 height=98></a></td>
<td><a href='../lib/request.php?Action=ViewIndicator&ch=4' ><img src='../imgs/l6.PNG' alt='' title='' border=0 width=105 height=98></a></td>
<td><a href='../lib/request.php?Action=ViewIndicator&ch=7' ><img src='../imgs/l7.PNG' alt='' title='' border=0 width=104 height=98></a></td>
<td>&nbsp;</td>
</tr>
</table>	
<br>


</form>
