<html>
<head>
  
<title>TBS-IM</title>
  
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</style>
</head>
<body bgcolor="#F4D03F" >
<table width="225" border="0" align="center">
  <tr>
    <th width="32" scope="col">
      <a href="../view/trans.php" TARGET="homes">
        <img src="../imgs/indicator.png"  title='Indicators manager' alt="" width="32" height="32"  />
      </a>
    </th>
   
    <th width="32" scope="col">
      <a href="../view/CreateBase.php" TARGET="homes">
        <img src="../imgs/base.png"  title='Ktbs Bases Manager' alt="" width="32" height="32"  />
      </a>
    </th>   
    <th width="32" scope="col">
      <a href="http://kernel-for-trace-based-systems.readthedocs.org/en/latest/" target="_blank">
        <img src="../imgs/aide.png"  title='KTBS Home Page' alt="" width="32" height="32" />
      </a>
    </th>
    
  </tr>
</table>
</body>
</html>

