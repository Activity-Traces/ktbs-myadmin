<?php

$Base_Name=$_REQUEST['BaseName'];

require_once("../config/config.php");
require_once("../lib/service.php");
$url=$ktbs_url.$Base_Name.'/';
$id= KTBS_Get_DataBase_info($url);

?>

<h3><b>Global Informations About this Base </h3></b>

<table align="left" border="0" cellpadding="1" cellspacing="1" >
	<tbody>
        <tr>
			<td><b>Base Name</b></td>
			<td>: <?php echo $Base_Name; ?></td>
		</tr>
		<tr>
			<td><b>Identifier</b></td>
			<td>: <?php echo $id[0]; ?></td>
		</tr>
		<tr>
			<td><b>Type</b></td>
            <td>: <?php echo $id[1]; ?></td>
		</tr>
		<tr>
			<td><b>Label</b></td>
			<td>: <?php echo $id[2]; ?></td>
		</tr>
		<tr>
			<td><b>In Root</b></td>
			<td>: <?php echo $id[3]; ?></td>
		</tr>
	</tbody>
</table>

<br><br><br>
<br><br><br>

<hr></hr>
<br>
<h3>	
    <form id="form1" name="form1"
	  method="post"
	  action="../lib/request.php?Action=AddTrace&BaseName=<?php echo $Base_Name;?>">
   <label for="textfield">Add a new trace to this Base</label>
  <input type="text" name="TraceName" id="TraceName">
   <input type="submit" name="Create" id="Create" value="    Create    ";"
   >
</form>

	
<br><hr></hr>


<b>List of traces:</b><br>
<?php

$url_test=$ktbs_url.$Base_Name.'/';
//echo $url_test."<br>";
$List_Traces=KTBS_Get_Traces_List($url_test);
if (!empty($List_Traces)){
  for($i=0;$i<count($List_Traces); $i++){
      $Trace=substr($List_Traces[$i],0,strlen($List_Traces[$i])-1);
      $link="../view/ViewTrace.php?TraceBase=".$Base_Name."&TraceName=".$Trace; 
       echo"<a href=".$link.">".$Trace."</a><br>";
   }
}   
else
echo "NULL";
?>
