<?php
session_start();


//****************************************************************************
// global variales uses to display obsels
//****************************************************************************

require_once("../config/config.php");
require_once("../lib/service.php");
require_once('help.php');

if   (isset($_GET["TraceName"]))
        $Trace=$_GET["TraceName"];
      

if   (isset($_GET["TraceBase"]))	
        $Base=$_GET["TraceBase"];


$url=$ktbs_url.$Base.'/'.$Trace.'/'.'@obsels';
$contains=KTBS_Get_Obsels_List($url);

Title_Indicator();

if (!empty($contains)){
	

	    foreach (array_keys($contains) as $key) {
		    $name="";
	$equation="";
	$description="";
	$values="";
	$timeval="";
	$transformation="";
	$sequence="";
	$id="";
	$type="";
	$begin="";
	$end="";
	$from="";
	$to="";
			if (isset($contains[$key]["@id"]))
	           $id = $contains[$key]["@id"];

			if (isset($contains[$key]["@type"]))
	           $type = $contains[$key]["@type"];

			if (isset($contains[$key]["begin"]))
	           $begin = $contains[$key]["begin"];
			
			if (isset($contains[$key]["end"]))
	           $end = $contains[$key]["end"];
			
			if (isset($contains[$key]["../IndicatorModel#description"]))   
	           $description= $contains[$key]["../IndicatorModel#description"];
			   
			if (isset($contains[$key]["../IndicatorModel#equation"]))
			   $equation = $contains[$key]["../IndicatorModel#equation"];		        
			
			if (isset($contains[$key]["../IndicatorModel#name"]))
			   $name= $contains[$key]["../IndicatorModel#name"];	        
			
			if (isset($contains[$key]["../IndicatorModel#TimeValue"]))
			   $timeval= $contains[$key]["../IndicatorModel#TimeValue"];	        
			
			if (isset($contains[$key]["http://localhost:8001/Indicators/IndicatorModel#Values"]))
			   $values= $contains[$key]["http://localhost:8001/Indicators/IndicatorModel#Values"];

			if (isset($contains[$key]["http://localhost:8001/Indicators/IndicatorModel#tname"]))
			   $transformation= $contains[$key]["http://localhost:8001/Indicators/IndicatorModel#tname"];	        
			
			if (isset($contains[$key]["http://localhost:8001/Indicators/IndicatorModel#tsequence"]))
			   $sequence= $contains[$key]["http://localhost:8001/Indicators/IndicatorModel#tsequence"];

            if (isset($contains[$key]["http://localhost:8001/Indicators/IndicatorModel#hasRelationOrigin"]))
			   $from= $contains[$key]["http://localhost:8001/Indicators/IndicatorModel#hasRelationOrigin"];

			if (isset($contains[$key]["http://localhost:8001/Indicators/IndicatorModel#hasRelationDestination"]))
			   $to= $contains[$key]["http://localhost:8001/Indicators/IndicatorModel#hasRelationDestination"];
            
            View_List_Indicators(
 	$name,
	$equation,
	$description,
	$values,
	$timeval,
	$transformation,
	$sequence,
	$id,
	$type,
	$begin,
	$end,
	$from,
	$to);
	

		}

		
}

else
{
		echo "OBSELS: NULL";
		
}

?>
