<html>
    <head>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="../style/treestyle2.css" />
	
	</head>
<body bgcolor="#F4D03F">
		
    <th width="32" scope="col"> <img src="../imgs/b2.png"  title='List of ktbs bases' />
      <b><FONT color="white">KTBS bases</FONT></b><p>


<?php
require "../config/config.php";
require "../lib/service.php";


$List_Bases=KTBS_Get_DataBase_List($ktbs_url);
if (!empty($List_Bases)){
   
   
    for($i=0;$i<count($List_Bases); $i++) {
        
		$Base=$List_Bases[$i];
        $Base=substr($Base,0,strlen($Base)-1);
		
        echo' <div class="css-treeview" style="overflow: auto;">			
				<li><input type="checkbox" id="item-1" checked="checked" />
				<label for="item-1">
				<a href=../view/ViewBase.php?BaseName='.$Base.' TARGET="homes">'.$Base.'</a>				
				</label>
				<ul>';
					       
        $url_test=$ktbs_url.$Base.'/';
        $List_Traces=KTBS_Get_Traces_List($url_test);
        if (!empty($List_Traces)){
           for($j=0;$j<count($List_Traces); $j++) {
		
		       $Trace=$List_Traces[$j];
		       $Trace=substr($Trace,0,strlen($Trace)-1);
	           if ($Base=='Indicators') {
	           	echo'<li>
			           <a href=../view/ViewIndicator.php?TraceName='.$Trace.
					          '&TraceBase='.$Base.
			                  ' TARGET="homes">'.$Trace.
			           '</a>
			        </li>';

	           }
	           else {
	            
		       echo'<li>
			           <a href=../view/ViewTrace.php?TraceName='.$Trace.
					          '&TraceBase='.$Base.
			                  ' TARGET="homes">'.$Trace.
			           '</a>
			        </li>';
			    }
			}
        }	
        echo'</ul></li></div><p>';

	}
}

?>

</html>
