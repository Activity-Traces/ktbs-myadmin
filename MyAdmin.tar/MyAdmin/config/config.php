<?php
$ktbs_url="http://localhost:8001/" ;
$user="admin";
$pwrd="";
?>
